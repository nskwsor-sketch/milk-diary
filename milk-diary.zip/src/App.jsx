import { useState, useEffect, useRef } from "react";

const STORAGE_KEY = "milk-diary-entries";

const milkTypes = [
  "普通牛乳", "低脂肪牛乳", "無脂肪牛乳", "成分無調整", "特濃",
  "低温殺菌", "ノンホモ", "有機牛乳", "A2ミルク", "その他"
];

const emptyForm = {
  name: "",
  brand: "",
  location: "",
  date: new Date().toISOString().split("T")[0],
  type: "普通牛乳",
  rating: 3,
  richness: 3,
  flavor: 3,
  notes: "",
  image: null,
};

const StarRating = ({ value, onChange }) => (
  <div style={{ display: "flex", gap: 5 }}>
    {[1,2,3,4,5].map(n => (
      <span key={n} onClick={() => onChange && onChange(n)}
        style={{
          fontSize: 26, cursor: onChange ? "pointer" : "default",
          filter: n <= value ? "none" : "grayscale(1) opacity(0.25)",
          transition: "transform 0.12s", display: "inline-block",
        }}
        onMouseEnter={e => { if(onChange) e.currentTarget.style.transform = "scale(1.25)" }}
        onMouseLeave={e => { e.currentTarget.style.transform = "scale(1)" }}
      >⭐</span>
    ))}
  </div>
);

const FlavorBar = ({ value, onChange }) => {
  const pct = ((value - 1) / 4) * 100;
  const label = value === 1 ? "しっかりチーズ" : value === 2 ? "チーズ寄り" : value === 3 ? "中間" : value === 4 ? "バター寄り" : "リッチバター";
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: "#d97706" }}>🧀 チーズ</span>
        <span style={{ fontSize: 13, fontWeight: 700, color: "#b45309" }}>🧈 バター</span>
      </div>
      <div style={{ position: "relative", height: 32, borderRadius: 16 }}>
        <div style={{
          position: "absolute", top: "50%", left: 0, right: 0,
          height: 14, borderRadius: 7, transform: "translateY(-50%)",
          background: "linear-gradient(90deg, #fde68a, #fbbf24, #f59e0b, #d97706)",
          boxShadow: "inset 0 2px 5px rgba(0,0,0,0.12)",
        }} />
        <input type="range" min={1} max={5} value={value}
          onChange={e => onChange && onChange(Number(e.target.value))}
          style={{
            position: "absolute", inset: 0, width: "100%", height: "100%",
            opacity: 0, cursor: onChange ? "pointer" : "default", margin: 0, zIndex: 2,
          }} />
        <div style={{
          position: "absolute", top: "50%",
          left: `calc(${pct}% * 0.88 + 6%)`,
          transform: "translate(-50%, -50%)",
          width: 30, height: 30, borderRadius: "50%",
          background: "#fff", boxShadow: "0 2px 10px rgba(0,0,0,0.2)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 15, pointerEvents: "none", transition: "left 0.1s",
          border: "2.5px solid #fbbf24",
        }}>
          {value <= 2 ? "🧀" : value >= 4 ? "🧈" : "🥛"}
        </div>
      </div>
      <div style={{ textAlign: "center", marginTop: 5, fontSize: 12, color: "#78909c", fontWeight: 600 }}>
        {label}
      </div>
    </div>
  );
};

export default function MilkDiary() {
  const [entries, setEntries] = useState([]);
  const [view, setView] = useState("list");
  const [form, setForm] = useState(emptyForm);
  const [selected, setSelected] = useState(null);
  const [saved, setSaved] = useState(false);
  const fileRef = useRef();

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setEntries(JSON.parse(raw));
    } catch {}
  }, []);

  const saveEntries = (next) => {
    setEntries(next);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch {}
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setForm(f => ({ ...f, image: ev.target.result }));
    reader.readAsDataURL(file);
  };

  const handleAdd = () => {
    if (!form.name || !form.location) return;
    const entry = { ...form, id: Date.now() };
    saveEntries([entry, ...entries]);
    setSaved(true);
    setTimeout(() => { setSaved(false); setView("list"); setForm(emptyForm); }, 1000);
  };

  const handleDelete = (id) => {
    saveEntries(entries.filter(e => e.id !== id));
    setView("list");
    setSelected(null);
  };

  const inputStyle = {
    width: "100%", background: "#f0f8ff", border: "2px solid #b3d9f5",
    borderRadius: 12, color: "#2c5f7a", padding: "10px 14px", fontSize: 14, outline: "none",
    fontFamily: "inherit", boxSizing: "border-box",
  };

  const Field = ({ label, emoji, children }) => (
    <div style={{ marginBottom: 15 }}>
      <label style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, fontWeight: 800,
        color: "#4a9cc0", marginBottom: 6, letterSpacing: 1, textTransform: "uppercase" }}>
        {emoji && <span style={{ fontSize: 13 }}>{emoji}</span>}{label}
      </label>
      {children}
    </div>
  );

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(160deg, #e4f2fc 0%, #f0f8ff 50%, #ffffff 100%)",
      fontFamily: "'Hiragino Maru Gothic Pro', 'Meiryo', sans-serif",
      color: "#2c5f7a",
    }}>
      <style>{`
        @keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
        @keyframes pop { 0%{transform:scale(0.92);opacity:0} 100%{transform:scale(1);opacity:1} }
        @keyframes shimmer { 0%{background-position:200%} 100%{background-position:-200%} }
        .thumb-card:hover { transform: scale(1.04); box-shadow: 0 8px 22px rgba(74,156,192,0.3) !important; }
        .thumb-card { transition: transform 0.18s, box-shadow 0.18s; }
        input:focus, select:focus, textarea:focus { border-color: #5bb8e8 !important; box-shadow: 0 0 0 3px rgba(91,184,232,0.18) !important; outline: none; }
      `}</style>

      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #b8dff5 0%, #d8eefb 50%, #eaf6ff 100%)",
        padding: "28px 20px 18px", textAlign: "center",
        borderBottom: "3px solid #c4e2f7", position: "relative", overflow: "hidden",
      }}>
        <div style={{ position: "absolute", top: 8, left: 14, fontSize: 18, opacity: 0.18 }}>☁️</div>
        <div style={{ position: "absolute", top: 12, right: 18, fontSize: 15, opacity: 0.18 }}>❄️</div>
        <div style={{ position: "absolute", bottom: 6, left: "42%", fontSize: 13, opacity: 0.13 }}>🐄</div>
        <div style={{ fontSize: 40, animation: "bounce 2.2s infinite", display: "inline-block" }}>🥛</div>
        <h1 style={{
          margin: "5px 0 2px", fontSize: 25, fontWeight: 900, letterSpacing: 3,
          background: "linear-gradient(90deg, #2980b9, #5bb8e8, #2980b9)",
          backgroundSize: "200% auto", WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent", animation: "shimmer 3s linear infinite",
        }}>牛乳日記</h1>
        <p style={{ margin: 0, fontSize: 11, color: "#7ab8d8", letterSpacing: 2 }}>✦ Milk Travel Diary ✦</p>
        <div style={{ marginTop: 10, display: "inline-block", background: "rgba(255,255,255,0.75)",
          padding: "4px 16px", borderRadius: 20, fontSize: 12, color: "#3a9fd4", fontWeight: 700 }}>
          {entries.length} 本 記録済み 🎉
        </div>
      </div>

      {/* Nav */}
      <div style={{ display: "flex", justifyContent: "center", gap: 10, padding: "14px 20px 0" }}>
        {[{ id: "list", label: "📷 ギャラリー" }, { id: "add", label: "＋ 追加" }].map(({ id, label }) => (
          <button key={id} onClick={() => { setView(id); if (id === "add") setForm(emptyForm); }} style={{
            background: view === id ? "linear-gradient(135deg, #3a9fd4, #5bb8e8)" : "#fff",
            border: "2px solid " + (view === id ? "#3a9fd4" : "#c4e2f7"),
            color: view === id ? "#fff" : "#3a9fd4",
            padding: "8px 24px", borderRadius: 50, cursor: "pointer",
            fontSize: 13, fontWeight: 700, fontFamily: "inherit",
            boxShadow: view === id ? "0 4px 14px rgba(58,159,212,0.35)" : "none",
            transition: "all 0.2s",
          }}>{label}</button>
        ))}
      </div>

      <div style={{ maxWidth: 520, margin: "0 auto", padding: "16px 12px 70px" }}>

        {/* GALLERY VIEW */}
        {view === "list" && (
          <div style={{ animation: "pop 0.3s ease" }}>
            {entries.length === 0 ? (
              <div style={{ textAlign: "center", padding: "50px 20px" }}>
                <div style={{ fontSize: 60 }}>🥛</div>
                <p style={{ fontSize: 16, color: "#3a9fd4", fontWeight: 700, marginTop: 12 }}>まだ記録がないよ！</p>
                <p style={{ fontSize: 13, color: "#90cde8" }}>旅先で飲んだ牛乳を追加しよう ☁️</p>
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
                {entries.map((e) => (
                  <div key={e.id} className="thumb-card"
                    onClick={() => { setSelected(e); setView("detail"); }}
                    style={{
                      aspectRatio: "1 / 1", borderRadius: 16, overflow: "hidden",
                      cursor: "pointer", position: "relative",
                      background: "linear-gradient(135deg, #c4e2f7, #e4f2fc)",
                      boxShadow: "0 3px 12px rgba(74,156,192,0.14)",
                      border: "2.5px solid #fff",
                    }}
                  >
                    {e.image
                      ? <img src={e.image} alt={e.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                      : <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
                          <span style={{ fontSize: 30 }}>🥛</span>
                        </div>
                    }
                    <div style={{
                      position: "absolute", bottom: 0, left: 0, right: 0,
                      background: "linear-gradient(transparent, rgba(20,60,100,0.75))",
                      padding: "16px 6px 6px",
                    }}>
                      <div style={{ fontSize: 10, fontWeight: 800, color: "#fff",
                        whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {e.name}
                      </div>
                      <div style={{ fontSize: 9, color: "rgba(255,255,255,0.85)", marginTop: 1 }}>
                        {"⭐".repeat(e.rating)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ADD VIEW */}
        {view === "add" && (
          <div style={{ animation: "pop 0.3s ease" }}>
            <div style={{ background: "#fff", borderRadius: 24, padding: "20px 16px",
              boxShadow: "0 4px 28px rgba(74,156,192,0.12)", border: "2px solid #ddeefb" }}>
              <h2 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 900, color: "#3a9fd4", textAlign: "center" }}>
                🥛 新しい牛乳を記録！
              </h2>

              <Field label="写真" emoji="📷">
                <div onClick={() => fileRef.current.click()} style={{
                  width: "100%", height: 140, borderRadius: 16, overflow: "hidden",
                  background: "linear-gradient(135deg, #e4f2fc, #ddeefb)",
                  border: "2.5px dashed #b3d9f5", display: "flex", alignItems: "center",
                  justifyContent: "center", cursor: "pointer",
                }}>
                  {form.image
                    ? <img src={form.image} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                    : <div style={{ textAlign: "center", color: "#7ab8d8" }}>
                        <div style={{ fontSize: 30 }}>📷</div>
                        <div style={{ fontSize: 11, marginTop: 6, fontWeight: 600 }}>タップして写真を選ぶ</div>
                      </div>
                  }
                </div>
                <input ref={fileRef} type="file" accept="image/*" onChange={handleImageUpload} style={{ display: "none" }} />
                {form.image && (
                  <button onClick={() => setForm(f => ({ ...f, image: null }))}
                    style={{ background: "none", border: "none", color: "#90cde8", fontSize: 12, cursor: "pointer", fontFamily: "inherit", marginTop: 4 }}>
                    × 写真を削除
                  </button>
                )}
              </Field>

              <Field label="牛乳の名前 *" emoji="📝">
                <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                  placeholder="例：十勝しぼりたて" style={inputStyle} />
              </Field>
              <Field label="メーカー・ブランド" emoji="🏭">
                <input value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value })}
                  placeholder="例：よつ葉乳業" style={inputStyle} />
              </Field>
              <Field label="飲んだ場所 *" emoji="📍">
                <input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })}
                  placeholder="例：北海道 帯広市" style={inputStyle} />
              </Field>
              <Field label="日付" emoji="📅">
                <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })}
                  style={{ ...inputStyle, colorScheme: "light" }} />
              </Field>
              <Field label="種類" emoji="🏷️">
                <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}
                  style={{ ...inputStyle, cursor: "pointer" }}>
                  {milkTypes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </Field>
              <Field label="総合評価" emoji="⭐">
                <StarRating value={form.rating} onChange={v => setForm({ ...form, rating: v })} />
              </Field>
              <Field label="コク・濃さ" emoji="💧">
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ fontSize: 11, color: "#90cde8", fontWeight: 700 }}>さっぱり</span>
                  <input type="range" min={1} max={5} value={form.richness}
                    onChange={e => setForm({ ...form, richness: Number(e.target.value) })}
                    style={{ flex: 1, accentColor: "#3a9fd4" }} />
                  <span style={{ fontSize: 11, color: "#3a9fd4", fontWeight: 700 }}>こってり</span>
                </div>
                <div style={{ textAlign: "center", fontSize: 16, marginTop: 2 }}>{"🥛".repeat(form.richness)}</div>
              </Field>
              <Field label="チーズ ↔ バター" emoji="🧀">
                <FlavorBar value={form.flavor} onChange={v => setForm({ ...form, flavor: v })} />
              </Field>
              <Field label="メモ・感想" emoji="💬">
                <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })}
                  placeholder="美味しかった！思い出を書こう ☁️" rows={3}
                  style={{ ...inputStyle, resize: "vertical", lineHeight: 1.7 }} />
              </Field>

              <button onClick={handleAdd} style={{
                width: "100%", padding: "14px", marginTop: 4,
                background: saved ? "linear-gradient(135deg, #86efac, #34d399)" : "linear-gradient(135deg, #3a9fd4, #5bb8e8)",
                border: "none", borderRadius: 16, color: "#fff", fontSize: 15, fontWeight: 900,
                cursor: "pointer", fontFamily: "inherit", letterSpacing: 1,
                boxShadow: "0 4px 16px rgba(58,159,212,0.38)", transition: "all 0.3s",
              }}>
                {saved ? "✅ 保存したよ！" : "🥛 記録する！"}
              </button>
            </div>
          </div>
        )}

        {/* DETAIL VIEW */}
        {view === "detail" && selected && (
          <div style={{ animation: "pop 0.3s ease" }}>
            <button onClick={() => setView("list")} style={{
              background: "#fff", border: "2px solid #c4e2f7", color: "#3a9fd4",
              borderRadius: 20, padding: "7px 18px", cursor: "pointer",
              fontSize: 12, fontWeight: 700, fontFamily: "inherit", marginBottom: 14,
            }}>← ギャラリーへ戻る</button>

            <div style={{ background: "#fff", borderRadius: 24, overflow: "hidden",
              boxShadow: "0 4px 24px rgba(74,156,192,0.15)", border: "2px solid #ddeefb" }}>
              <div style={{ height: 200, background: "linear-gradient(135deg, #c4e2f7, #e4f2fc)",
                display: "flex", alignItems: "center", justifyContent: "center" }}>
                {selected.image
                  ? <img src={selected.image} alt={selected.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  : <span style={{ fontSize: 60 }}>🥛</span>
                }
              </div>

              <div style={{ padding: "18px 16px" }}>
                <h2 style={{ margin: "0 0 3px", fontSize: 20, fontWeight: 900, color: "#2c5f7a" }}>{selected.name}</h2>
                {selected.brand && <p style={{ margin: "0 0 10px", fontSize: 12, color: "#7ab8d8", fontWeight: 600 }}>{selected.brand}</p>}
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                  <StarRating value={selected.rating} />
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 14 }}>
                  {[
                    ["📍", "場所", selected.location],
                    ["📅", "日付", selected.date],
                    ["🏷️", "種類", selected.type],
                    ["💧", "コク", "🥛".repeat(selected.richness)],
                  ].map(([emoji, label, val]) => (
                    <div key={label} style={{ background: "#f0f8ff", borderRadius: 12, padding: "9px 11px", border: "1.5px solid #ddeefb" }}>
                      <div style={{ fontSize: 15, marginBottom: 2 }}>{emoji}</div>
                      <div style={{ fontSize: 10, color: "#90cde8", fontWeight: 700, marginBottom: 2 }}>{label}</div>
                      <div style={{ fontSize: 12, color: "#2c5f7a", fontWeight: 700 }}>{val}</div>
                    </div>
                  ))}
                </div>

                <div style={{ background: "#fffbeb", borderRadius: 12, padding: "12px 14px", marginBottom: 12, border: "1.5px solid #fde68a" }}>
                  <div style={{ fontSize: 11, color: "#d97706", fontWeight: 800, marginBottom: 8 }}>🧀 チーズ ↔ バター 🧈</div>
                  <FlavorBar value={selected.flavor ?? 3} onChange={null} />
                </div>

                {selected.notes && (
                  <div style={{ background: "#f0f8ff", borderRadius: 12, padding: "11px 14px", marginBottom: 12, border: "1.5px solid #ddeefb" }}>
                    <div style={{ fontSize: 11, color: "#3a9fd4", fontWeight: 800, marginBottom: 4 }}>💬 メモ</div>
                    <p style={{ margin: 0, fontSize: 13, color: "#2c5f7a", lineHeight: 1.7 }}>{selected.notes}</p>
                  </div>
                )}

                <button onClick={() => handleDelete(selected.id)} style={{
                  width: "100%", padding: "11px", background: "#fff5f5",
                  border: "2px dashed #fca5a5", borderRadius: 12,
                  color: "#f87171", fontSize: 13, fontWeight: 700,
                  cursor: "pointer", fontFamily: "inherit",
                }}>🗑️ この記録を削除</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
